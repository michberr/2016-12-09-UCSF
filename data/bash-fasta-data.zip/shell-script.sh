# Grep for DR1 or DR2
grep -B 1 -E "GTTCCAATTAATCTTAAACCCTACTAGGGATTGAAAC|GTTCCAATTAATCTTAAACCCTATTAGGGATTGAAAC" dt_int.fasta > myGrepHits.fasta

# Grep for reverse complement
grep -B 1 -E "GTTTCAATCCCTAGTAGGGTTTAAGATTAATTGGAAC|GTTTCAATCCCTAATAGGGTTTAAGATTAATTGGAAC" dt_int.fasta >> myGrepHits.fasta

# Remove "--" lines
grep -v \\-- myGrepHits.fasta>myFormatGrepHits.fasta

# Run blast against virome database
blastn -db E0108-V-allcontigs.fa -query sample.fasta -outfmt 6

